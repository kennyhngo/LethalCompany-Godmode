# ToggleableGodmode

Sometimes you want to die, sometimes you don't.

## Things you can die from

- Mines
- Falling down in facility
- Quicksand
- Lightning
- Monsters that can one shot (bracken, ghost girl, giant, etc)

## Things you cannot die from

- Gravity
- Monsters
- Bees
- Turrets
